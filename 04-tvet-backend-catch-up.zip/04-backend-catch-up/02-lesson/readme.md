# Classes 


Classes consist of Members
    - field
    - method

Scripts consist of variables, functions, objects

# Members:

 - must have an access modifier

 - We use members of a class outside a class by referencing it via the class for static methods, 

 - or an instance of a class of properties or instance methods


# Access Modifiers:

- if a memeber is public it can referenced / used outside a class

- if a member is private no matter what we cannot use it outside a class