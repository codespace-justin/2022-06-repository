<?php
/**
 * Name: success.php
 * Description: Standard webpage to output a message on the successful purchase of a vehicle
 * Author: justin@codespace.co.za
 */
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Success!</title>
</head>
<body>
    <h1>
        Congratulations on the purchase of your new car!
    </h1>

    <h2>
        Please head down to the a dealership near your to fill in the necessary paper so your car may be shipped to you.
    </h2>
</body>
</html>