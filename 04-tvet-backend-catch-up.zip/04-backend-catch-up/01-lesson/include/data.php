<?php

$items = [ 
    [
        "name" => "LG",
        "price" => 100,
        "barcode" => "#fjv3"
    ], 
    [
        "name" => "HiSense",
        "price" => 80,
        "barcode" => "#45v3"
    ],     [
        "name" => "Samsung",
        "price" => 100,
        "barcode" => "#evj3"
    ],     [
        "name" => "JVC",
        "price" => 70,
        "barcode" => "#c93j"
    ]
];